﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EMSProject.Models
{
    public class Employees
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage ="Please enter first name")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Please enter first name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please enter email address")]
        [Display(Name = "Email Address")]
        [EmailAddress]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter Mobile number")]
        [Display(Name = "Mobile Number")]
        [Phone]
        public string Mobile { get; set; }
        public bool IsActive { get; set; }
        public int CreatedById { get; set; }

    }
}
