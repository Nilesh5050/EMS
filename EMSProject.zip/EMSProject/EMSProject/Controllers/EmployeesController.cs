﻿using EMSProject.Models;
using EMSProject.Respository.Contract;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;

namespace EMSProject.Controllers
{
    [Authorize]
    public class EmployeesController : Controller
    {
        private IEmployees employeeService;
        private EMSDBContext db;
        public EmployeesController(IEmployees context, EMSDBContext _db)
        {
            employeeService = context;
            db = _db;
        }
        public IActionResult Index()
        {
            var createById = HttpContext.Session.GetInt32("Id");
            var employee = employeeService.GetEmployee((int)createById);
            return View(employee);


        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]

        
        public IActionResult Create(Employees obj)
        {
            var createById = HttpContext.Session.GetInt32("Id");
            obj.CreatedById = ((int)createById);
            employeeService.CrateEmployee(obj);
            return RedirectToAction("Index");
            
        }

        public IActionResult Edit(int id)
        {
            
            var emp = employeeService.GetEmployeeById(id);
            return View(emp);
        }
        [HttpPost]
        public IActionResult Edit(Employees obj)
        {
            if (ModelState.IsValid)
            {
                var createById = HttpContext.Session.GetInt32("Id");
                obj.CreatedById = ((int)createById);
                employeeService.UpdateEmployee(obj);
                return RedirectToAction("Index");
            }
            return View(obj);
        }

        
        public IActionResult Delete(int id)
        {
            employeeService.DeleteEmployee(id);
            return RedirectToAction("Index");
        }
    }
}
