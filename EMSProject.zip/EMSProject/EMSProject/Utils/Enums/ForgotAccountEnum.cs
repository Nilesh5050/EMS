﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EMSProject.Utils.Enums
{
    public enum ForgotAccountEnum
    {
        OTPEXPRIED,
        OTPVERIFIED,
        INVALIDOTP
    }
}
