﻿using EMSProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EMSProject.Respository.Contract
{
    
    public interface IEmployees
    {
        List<Employees> GetEmployee(int createById);
        Employees CrateEmployee(Employees obj);
        Employees UpdateEmployee(Employees obj);
        bool DeleteEmployee(int? id);
        Employees GetEmployeeById(int id);
    }
}
