﻿using EMSProject.Models;
using EMSProject.Respository.Contract;
using Microsoft.AspNetCore.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace EMSProject.Respository.Service
{
    public class EmployeesService : IEmployees
    {
        private EMSDBContext _dbContext;

        public object Request { get; private set; }

        public EmployeesService(EMSDBContext dbContext)
        {
            _dbContext=dbContext;
        }

        public Employees CrateEmployee(Employees obj)
        {
            if (obj != null)
            {
                _dbContext.Add(obj);
                _dbContext.SaveChanges();
                return obj;
            }
            return null;


        }



        public bool DeleteEmployee(int? id)
        {
            if (id == null)
            {
                return false;
            }
            var emp = _dbContext.Employees.Find(id);

            _dbContext.Employees.Remove(emp);
            _dbContext.SaveChanges();
            return true;

        }

        public List<Employees> GetEmployee(int createById)
        {
            
            var employee = _dbContext.Employees.Where(x=>x.CreatedById==createById).ToList();
            return employee;
        }

        public Employees GetEmployeeById(int id)
        {
            var emp = _dbContext.Employees.Find(id);
            return emp;
        }

        public Employees UpdateEmployee(Employees obj)
        {
            if (obj != null)
            {
                _dbContext.Employees.Update(obj);
                _dbContext.SaveChanges();
                return obj;
            }
            return null;
        }
    }
}
